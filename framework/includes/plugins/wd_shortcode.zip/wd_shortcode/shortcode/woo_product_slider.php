<?php
/**
 * @package WordPress
 * @since WD_Dance
 */

if(!function_exists('wd_product_slider_function')){
	function wd_product_slider_function($atts){
		global $woocommerce_loop, $woocommerce;
		extract(shortcode_atts(array(
			'columns' 			=> 4,
			'per_page' 			=> 8,
			'order' 			=> 'date',
			'orderby'			=> 'desc',
			'product_cats' 		=> '',
			'show_type'         => 'grid',
			'show_feature'		=> 'no',
		),$atts));
		
		$_actived = apply_filters( 'active_plugins', get_option( 'active_plugins' )  );
		if ( !in_array( "woocommerce/woocommerce.php", $_actived ) ) {
			return;
		}
		$meta_query = $woocommerce->query->get_meta_query();	
		$tax_query   = $woocommerce->query->get_tax_query();
		if(strcmp('yes',$show_feature) == 0){
			$tax_query[] = array(
				'taxonomy' => 'product_visibility',
				'field'    => 'name',
				'terms'    => 'featured',
				'operator' => 'IN',
			);
		}
		
		if($product_cats !== '' ){
			$tax_query[] = array(
				'taxonomy' => 'product_cat',
				'terms' => array( esc_attr($product_cats) ),
				'field' => 'id',
				'include_children' => false
			);
		}

		$args = array(
			'post_type'	=> 'product',
			'post_status' => 'publish',
			'ignore_sticky_posts'	=> 1,
			'posts_per_page' => $per_page,
			'order' => $order,
			'orderby' => $orderby,
			'meta_query' => $meta_query,
			'tax_query'  => $tax_query
		);
		
		ob_start();
		$_old_woocommerce_loop = $woocommerce_loop['columns'];
		$products = new WP_Query($args);
		$woocommerce_loop['columns'] = $columns;
		?>
		<?php $rand_id = rand(); ?>
		<div class="product_category " > 
				<div class="products <?php echo esc_attr($show_type); ?>">	
					 <?php if ($products->have_posts()): ?>
						<div id="wd_product_slider_<?php echo $rand_id; ?>" class="owl-carousel owl-theme">
						<?php while ($products->have_posts()): $products->the_post(); ?>
							<ul class="item">
								<?php wc_get_template_part( 'content', 'product' ); ?>
							</ul>
						<?php endwhile; ?>
						</div>
					<?php endif; ?>
				</div>
		</div>	
		<script type="text/javascript">
		jQuery(document).ready(function() {
			jQuery("#wd_product_slider_<?php echo $rand_id; ?>").owlCarousel({
				navigation : false,
				autoplay:true,
				loop:true,
				autoHeight:true,
				autoplayTimeout:4000,
				autoplayHoverPause:true,
				items:4,
				navigation: true,
				navigationText: ["<",">"]
			});
		});
		</script>
		<?php 
		wp_reset_postdata();
		$woocommerce_loop['columns'] = $_old_woocommerce_loop;
		return '<div class="woocommerce">' . ob_get_clean() . '</div>';		
	}
}

add_shortcode('wd_product_cat_slider','wd_product_slider_function');
?>